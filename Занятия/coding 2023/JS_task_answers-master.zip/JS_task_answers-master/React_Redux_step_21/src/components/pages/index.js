import MainPage from "./MainPage";
import ComicsPage from "./ComicsPage";

export {MainPage, ComicsPage};