import MainPage from './main-page';
import CartPage from './cart-page';
import ItemPage from './itemPage';

export {
    MainPage,
    CartPage, 
    ItemPage
};