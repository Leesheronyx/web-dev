import React from 'react';

const RestoServiceContext = React.createContext(); // Создаем константу с контекстом

export default RestoServiceContext;
