import CharDetails, {Field} from './itemDetails';
export {Field};
export default CharDetails;